class Tank {
  // Member Variable
  float x, y, w, h, speed, health;
  PImage iTankW;
  PImage iTankA;
  PImage iTankS;
  PImage iTankD;
  PImage Bomb;
  PImage Health;
  char idir;

  // Constructor
  Tank() {
    x = 100.0;
    y = 100.0;
    w = 100.0;
    h = 100.0;
    speed = 2.0;
    health = 75.0;
    iTankW = loadImage("tankW.png");
    iTankA = loadImage("tankA.png");
    iTankS = loadImage("tankS.png");
    iTankD = loadImage("tankD.png");
    Bomb = loadImage("kleven_bomb.png");
    Health = loadImage("health.png");
    idir = 'w';
  }

  void display() {
  imageMode(CENTER);
  
  // Check which direction the tank is facing and draw that image
  if (idir == 'w' && iTankW != null) {
    image(iTankW, x, y);
  } else if (idir == 'a' && iTankA != null) {
    image(iTankA, x, y);
  } else if (idir == 's' && iTankS != null) {
    image(iTankS, x, y);
  } else if (idir == 'd' && iTankD != null) {
    image(iTankD, x, y);
  }
}

void move(char dir) {
  idir = dir; // Update the facing direction whenever the tank moves
  
  if (dir == 'w') {
    y = y - speed;
  } else if (dir == 's') {
    y = y + speed;
  } else if (dir == 'a') {
    x = x - speed;
  } else if (dir == 'd') {
    x = x + speed;
  }
}


void fire() {
}

}
