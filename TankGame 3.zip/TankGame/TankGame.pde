// Lucy Kleven | April 1, 2026 | Tank Game
Heart h1; 
PImage bg1; 
Tank t1; 
ArrayList<Bomb> bombs;
ArrayList<Bullet> bullets; // New: list for triangles

void setup() { 
  size(500, 500); 
  bg1 = loadImage("bg1.png"); 
  t1 = new Tank(); 
  bombs = new ArrayList<Bomb>(); 
  bullets = new ArrayList<Bullet>(); 
  h1 = new Heart(random(50, 450), random(50, 450), 40, 40, 20); 
} 

void draw() { 
  if (bg1 != null) background(bg1); 
  if (t1.health > 0) { 
    t1.display(); 
    
    // Spawn bombs - Increased size from 30x30 to 60x60
    if (frameCount % 190 == 0) { 
      bombs.add(new Bomb(random(width), -50, 60, 60, 10, random(2, 5))); 
    } 

    // Process bullets (orange triangles)
    for (int i = bullets.size() - 1; i >= 0; i--) {
      Bullet b = bullets.get(i);
      b.move();
      b.display();
      
      // Check for collision with bombs
      for (int j = bombs.size() - 1; j >= 0; j--) {
        Bomb bomb = bombs.get(j);
        if (dist(b.x, b.y, bomb.x, bomb.y) < bomb.w/2) {
          bombs.remove(j); // Destroy bomb
          bullets.remove(i); // Destroy triangle
          break; 
        }
      }
      
      // Remove bullet if it goes off screen
      if (i < bullets.size() && (b.y < 0 || b.y > height || b.x < 0 || b.x > width)) {
        bullets.remove(i);
      }
    }

    // Process bombs 
    for (int i = bombs.size() - 1; i >= 0; i--) { 
      Bomb b = bombs.get(i); 
      b.move(); 
      b.display(t1.bombImg); 
      if (t1.hitBomb(b)) { 
        t1.health -= b.val; 
        bombs.remove(i); 
      } else if (b.y > height + 50) { 
        bombs.remove(i); 
      } 
    } 

    h1.display(t1.heartImg); 
    if (t1.hitHeart(h1)) { 
      t1.health += h1.val; 
      h1.reset(); 
    } 

    fill(255); 
    textSize(20); 
    text("Health: " + t1.health, 20, 30); 
  } else { 
    background(0); 
    fill(255, 0, 0); 
    textAlign(CENTER); 
    textSize(40); 
    text("GAME OVER", width/2, height/2); 
  } 
} 

void keyPressed() { 
  t1.move(key); 
  // Shoot a triangle when SPACE is pressed
  if (key == ' ') {
    bullets.add(new Bullet(t1.x, t1.y, t1.idir));
  }
}
