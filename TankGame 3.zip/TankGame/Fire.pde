class Bullet {
  float x, y, speed;
  char dir;
  float size = 15;

  Bullet(float x, float y, char dir) {
    this.x = x;
    this.y = y;
    this.dir = dir;
    this.speed = 7;
  }

  void move() {
    if (dir == 'w') y -= speed;
    else if (dir == 's') y += speed;
    else if (dir == 'a') x -= speed;
    else if (dir == 'd') x += speed;
  }

  void display() {
    pushMatrix();
    translate(x, y);
    // Rotate triangle based on direction
    if (dir == 's') rotate(PI);
    else if (dir == 'a') rotate(-HALF_PI);
    else if (dir == 'd') rotate(HALF_PI);
    
    fill(255, 120, 0); // Orange
    noStroke();
    triangle(0, -size/2, -size/2, size/2, size/2, size/2);
    popMatrix();
  }
}
