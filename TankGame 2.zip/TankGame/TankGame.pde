// Lucy Kleven | April 1, 2026 | Tank Game 
Tank t1; 
ArrayList<Bomb> bombs; 
Heart h1; 
PImage bg1; 

void setup() { 
  size(500, 500); 
  bg1 = loadImage("bg1.png"); 
  t1 = new Tank(); 
  bombs = new ArrayList<Bomb>(); 
  h1 = new Heart(random(50, 450), random(50, 450), 40, 40, 20); 
} 

void draw() { 
  if (bg1 != null) background(bg1); 
  
  if (t1.health > 0) { 
    t1.display(); 
    
    // CHANGE THIS NUMBER TO SPAWN LESS OFTEN
    // 180 frames = roughly every 3 seconds
    if (frameCount % 180 == 0) { 
      bombs.add(new Bomb(random(width), -50, 30, 30, 10, random(2, 5))); 
    } 
    
    // Process bombs
    for (int i = bombs.size() - 1; i >= 0; i--) { 
      Bomb b = bombs.get(i); 
      b.move(); 
      b.display(t1.bombImg); 
      
      if (t1.hitBomb(b)) { 
        t1.health -= b.val; 
        bombs.remove(i);    
      } else if (b.y > height + 50) { 
        bombs.remove(i);    
      } 
    } 
    
    // Heart logic
    h1.display(t1.heartImg); 
    if (t1.hitHeart(h1)) { 
      t1.health += h1.val; 
      h1.reset(); 
    } 
    
    fill(255); 
    textSize(20);
    text("Health: " + t1.health, 20, 30); 
    
  } else { 
    background(0); 
    fill(255, 0, 0); 
    textAlign(CENTER); 
    textSize(40);
    text("GAME OVER", width/2, height/2); 
  } 
} 

void keyPressed() { 
  t1.move(key); 
}
