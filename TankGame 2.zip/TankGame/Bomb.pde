class Bomb { 
  float x, y, w, h, val, speed; 

  Bomb(float x, float y, float w, float h, float v, float s) { 
    this.x = x; 
    this.y = y; 
    this.w = w; 
    this.h = h; 
    this.val = v;    // This is the amount of health to subtract
    this.speed = s; 
  } 

  void display(PImage img) { 
    imageMode(CENTER); 
    if (img != null) {
      image(img, x, y, w, h); 
    } else {
      // Fallback if image fails to load
      fill(255, 0, 0);
      ellipse(x, y, w, h);
    }
  } 

  void move() { 
    y += speed; // Moves the bomb down the screen
  } 
}
