class Tank {
  float x, y, w, h, speed, health;
  char idir;
  PImage iTankW, iTankA, iTankS, iTankD, bombImg, heartImg;

  Tank() {
    x = 250;
    y = 250;
    w = 80;
    h = 80;
    speed = 4.0;
    health = 75.0;
    idir = 'w';
    iTankW = loadImage("tankW.png");
    iTankA = loadImage("tankA.png");
    iTankS = loadImage("tankS.png");
    iTankD = loadImage("tankD.png");
    bombImg = loadImage("kleven_bomb.png");
    heartImg = loadImage("health.png");
  }

  void display() {
    imageMode(CENTER);
    if (idir == 'w') image(iTankW, x, y, w, h);
    else if (idir == 'a') image(iTankA, x, y, w, h);
    else if (idir == 's') image(iTankS, x, y, w, h);
    else if (idir == 'd') image(iTankD, x, y, w, h);
  }

  void move(char dir) {
    idir = dir;
    if (dir == 'w') y -= speed;
    else if (dir == 's') y += speed;
    else if (dir == 'a') x -= speed;
    else if (dir == 'd') x += speed;
  }

  // Circle collision detection
  boolean hitBomb(Bomb b) {
    float d = dist(this.x, this.y, b.x, b.y);
    if (d < 40) { // Adjust '40' based on your tank's size
      return true;
    }
    return false;
  }
  boolean hitHeart(Heart hrt) {
    return dist(x, y, hrt.x, hrt.y) < (w/2 + hrt.w/2);
  }
}
